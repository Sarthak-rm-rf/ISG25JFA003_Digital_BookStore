import { Component } from "@angular/core";

@Component({
    selector: 'home-page',
    imports: [],
    templateUrl: './home-page.html'
})

export class HomePage {
    title = 'ISG25JFA003_Digital_BookStore';
}