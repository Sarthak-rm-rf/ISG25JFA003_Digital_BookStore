import { Routes } from '@angular/router';
import { ReviewsManagementComponent } from './reviews-management';

export default [
  {
    path: '',
    component: ReviewsManagementComponent,
  },
] as Routes;
