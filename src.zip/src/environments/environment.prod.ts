export const environment = {
  production: true,
  apiUrl: 'http://localhost:8080/api/v1', // Update with production URL when deploying
  razorpayKey: 'rzp_test_1234567890' // Update with production key when deploying
};

