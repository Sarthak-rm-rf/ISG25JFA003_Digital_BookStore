export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api/v1',
  razorpayKey: 'rzp_test_1DP5mmOlF5G5ag' // Valid test key
};

