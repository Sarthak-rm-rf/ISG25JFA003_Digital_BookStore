import { Component } from '@angular/core';

@Component({
  selector: 'app-progress-tracker',
  imports: [],
  templateUrl: './progress-tracker.html',
  styleUrl: './progress-tracker.css'
})
export class ProgressTracker {

}
